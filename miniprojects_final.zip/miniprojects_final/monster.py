# print('야생의 몬스터가 나타났다.')
# print(R'''
#   oo`'._..---.___..-
#  (_,-.        ,..'`
#       `'.    ;
#          : :`
#         _;_;     
# ''')
import random as r

class Monster:
    '''몬스터 클래스입니다.'''
    def __init__(self, name, health, AP, drop):
        self.name = name
        self.HP = health
        self.drop = drop
        self.AP = AP
    
    def random_drop(self):
        drop_item = [r.choice(self.drop)]+['동전']*r.randint(1,5)
        return drop_item