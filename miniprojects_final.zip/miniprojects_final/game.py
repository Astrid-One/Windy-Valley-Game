import os
import time
from art import text2art, tprint

from opening import *
from character import *
from fight import *
from management import *
from map import *
from fight import Fight


class Game():
    '''게임을 해볼까요?'''
    def __init__(self, current_place):
        self.name = "New World"
        self.running = True
        self.current_place = current_place

    @staticmethod
    def clear_screen():
        """터미널 화면을 지우는 함수"""
        os.system('cls' if os.name == 'nt' else 'clear')

    # 장소 이름 출력
    def place(self):
        '''장소 이동시 화면 초기화 및 장소이름 출력'''
        # self.clear_screen()
        print()
        print(f"당신은 {self.current_place.name}에 있습니다.")
        pass


    def take_object(self, user_character):
        if self.current_place.get_number_objects() == 0:
            print("이곳에는 가져갈만한 물건이 없습니다.\n")
        else:
            print("\n무엇을 가져가시겠습니까?")
            self.current_place.display_place_objects()
            choice = -1
            while int(choice) < 0 or int(choice) > self.current_place.get_number_objects():
                try:
                    choice = int(input())
                    if choice < 1 or choice > self.current_place.get_number_objects():
                        print("유효한 선택이 아닙니다. 다시 입력해 주세요.\n")
                    else:
                        user_character.in_item(self.current_place.get_place_object(choice-1))
                        user_character.check_inventory()
                        del self.current_place.objects[int(choice) - 1]
                        break
                except ValueError:
                    print("숫자를 입력해 주세요.\n")

    def take_monster(self, user_character):
        if self.current_place.get_number_monsters() == 0:
            print("이곳에는 몬스터가 없습니다.\n")
        else:
            print("어떤 몬스터와 싸우겠습니까?")
            self.current_place.display_place_monsters()
            choice = -1
            while int(choice) < 0 or int(choice) > self.current_place.get_number_monsters():
                try:
                    choice = int(input())
                    if choice < 1 or choice > self.current_place.get_number_monsters():
                        print("유효한 선택이 아닙니다. 다시 입력해 주세요.\n")
                    else:
                        pause_first_song()
                        result = Fight.run_fight(user_character, self.current_place.get_place_monsters(choice-1))
                        return result
                except ValueError:
                    print("숫자를 입력해 주세요.\n")

    def talk_to_npc(self):
        if self.current_place.get_number_npc() == 0:
            print("이곳에는 상호작용할 수 있는 것이 없습니다.\n")
        else:
            print("누구와 얘기하고 싶나요? 또는 무엇을 자세히 살펴볼까요?\n")
            self.current_place.display_place_npc()
            choice = -1
            while int(choice) < 0 or int(choice) > self.current_place.get_number_npc():
                choice = input()
            self.current_place.npc[int(choice) - 1].greeting()
            self.current_place.npc[int(choice) - 1].saying()
        

    def user_choice(self, user_character):
        input1 = input("\n1.둘러보기 2.이동하기 3.가방 확인하기 4.소지금 확인하기 5.춤추기 6.게임 종료\n내 답변:")
        if input1=='1':
            print("----  당신은【" + self.current_place.name + "에 있습니다. ----\n")
            print(f"--- {self.current_place.name}에 있는 몬스터 ---")
            self.current_place.display_place_monsters()
            print(f"--- {self.current_place.name}에 있는 아이템 ---")
            self.current_place.display_place_objects()
            print(f"--- {self.current_place.name}에 있는 NPC ---")
            self.current_place.display_place_npc()
            
            input2 = input("1.싸우기 2.가져가기 3.대화하기 4.메뉴\n내 답변:")

            #fight
            if input2 == '1':
                result=self.take_monster(user_character)
                pause_first_song()
                if result == True:
                    stop_music_fightchannel()
                    resume_first_song()
                else:
                    return False
            #take
            elif input2 == '2':
                self.take_object(user_character)
            #talk
            elif input2 == '3':
                self.talk_to_npc()
            #menu
            else:
                print("\n*** Back to menu ***\n")
                return True
            return True
        #move
        elif input1 == '2':
            self.current_place = show_location_options(self.current_place)
            return True
        elif input1 == '3':
            user_character.check_inventory()
            return True
        elif input1 =='4':
            user_character.open_wallet()
            return True
        elif input1 == '5':
            pause_first_song()
            dance()
            resume_first_song()
            return True
        elif input1 == '6':
            return False
        else:
            return True

    def run(self):
        #game setting
        play_first_song()
        self.clear_screen()
        opening()
        story()
        self.clear_screen()
        user_character = create_character()
        while self.running:
            self.place()
            self.current_place.display_msg()
            self.runnung = location_event(user_character,self.current_place.name)
            self.running = self.user_choice(user_character)
            

def show_location_options(current_place):
    print("\n현재 가능한 장소는 다음과 같습니다:")
    options = ""
    i = 0
    directions = ["북쪽", "동쪽", "남쪽", "서쪽"]
    for direction, place in zip(directions, current_place.adjacents_room):
        if place is not None:
            i += 1
            options += f"{i}. {place.name} ({direction})  "
    print("어디로 가시겠습니까?")
    choice = input(options + '\n내 답변:')
    choice_int = int(choice) - 1
    valid_directions = [i for i, room in enumerate(current_place.adjacents_room) if room is not None]

    if choice_int in range(len(valid_directions)):
        current_place = current_place.adjacents_room[valid_directions[choice_int]]
        return current_place

#$$$
def location_event(user_character,current_place):
    if current_place == '상점 앞':
        shopping(user_character)
        return True
    elif current_place == '버려진 계곡':
        if '에테르의 기운이 맴도는 목걸이' in user_character.inventory:
            pause_first_song()
            dragon  = Monster("에테리온 드래곤", 3000, 100, ['생명의 뿌리', '황금스프','생명의 앨릭서'])
            dragon_fight = Fight(user_character, dragon)
            result = dragon_fight.dragon_event(user_character, dragon)
            stop_music_fightchannel()
            resume_first_song()
            return result

def dance():
    play_dance_song()
    frames = [
        "   O\n  <|>\n* / \\",
        "   O\n  /|>\n  / \\ *",
        " *\\O\n   |>\n  / \\",
        "   O/ *\n  <|\n  / \\"
            ]
    i = 0
    while i < 6:
        for frame in frames:
            os.system('cls' if os.name == 'nt' else 'clear')
            print(frame)
            time.sleep(0.57)  # Adjust the speed of the animation
        i += 1
    stop_music_dancechannel()


def shopping(user_character):
    userChoice_shop = input("상점에 들어간다? 1.네   2.아니오\n내 답변:").strip()
    # 판매 리스트
    while (int(userChoice_shop) == 1):
        salelist = make_salelist()
        saleProduct = list(salelist.keys())
        salePrice = list(salelist.values())
        # 상점 이름
        tprint("shop", font="Slant")
        play_shop()
        print('**딸랑** \n상점 주인: 어서오세요. 없는 거 빼고 다 있습니다. 천천히 둘러보시죠~')
        while (userChoice_shop == '1'):
            purchase_item = input(f'상점 주인: 뭘 사시렵니까? 1.{saleProduct[0]}({salePrice[0]}코인)   2.{saleProduct[1]}({salePrice[1]}코인)   3.{saleProduct[2]}({salePrice[2]}코인)   4.{saleProduct[3]}({salePrice[3]}코인)   5.안사요\n내 답변:').strip()
            if purchase_item not in ['1','2','3','4','5']:
                print('상점 주인: 그런건 없소.\n나:(흐음...아무래도 번호를 잘못 말한거 같다)\n')
            elif purchase_item in ['1','2','3','4']:
                for i in range(4):
                    if purchase_item == str(i+1):
                        if user_character.pay_money(salePrice[i]):
                            user_character.in_item([saleProduct[i]])
                            user_character.check_inventory()
                        else:
                            print(f'당신의 소지금 {user_character.get_wallet()}보다 상품의 가격 {salePrice[i]}이 더 비쌉니다.')
            else:
                print("상점 주인: * 크흠 * 정말 안사시오?\n")

            userChoice_shop = input("계속 구매하시겠습니까? 1.네    2.아니오\n내 답변:")
        print('안녕히가세요~\n')
        play_shopbell_sound()
    time.sleep(1.5)
    stop_music_shopchennel()
    resume_first_song()