import random as r

# items(herbs, potions, armor, foods ,coin)
class Items:
    def __init__(self, name,price):
        self.name = name
        self.price = price

class Herb(Items):
    def __init__(self, name, price, potion_name=None):
        super().__init__(name,price)
        self.potion_name = potion_name
                               
class Potion(Items):
    def __init__(self, name, price, HP):
        super().__init__(name,price)
        self.price = price
        self.HP = HP

    def heal(self, user):
        return user.HP + self.HP

class Armor(Items):
    def __init__(self, name, price, protection=None, AP=None):
        super().__init__(name,price)
        self.protection = protection
        self.AP = AP

class Food(Items):
    def __init__(self, name, price):
        super().__init__(name,price)

class QuestItem(Items):
    def __init__(self,name,price):
        super().__init__(name,price)
        

# 굳이 필요없을 거 같음 100으로 고정하니깐
# class Coin(Items):
#     def __init__(self):
#         pass     #코인은 하나 당 100원 그리고 얻으면 바로 지갑으로 들어감



## ItemList(방법2) --> if 이 방법 쓰면 each_list를 class Item에서 만드는 방법 없애야 함
all_item_dict ={}
herb_dict = {}
potion_dict = {}
armor_dict = {}
food_dict = {}
all_item_dict.update({'herbs':herb_dict,'potions':potion_dict, 'armors':armor_dict, 'foods':food_dict})

## Create Item Func.
def create_herb(name, price, potion_name=None):
    herb_dict.update({name:Herb(name, price, potion_name)})

def create_potion(name, price, HP):
    potion_dict.update({name:Potion(name, price, HP)})

def create_armor(name, price, protection=None, AP=None):
    armor_dict.update({name:Armor(name, price, protection, AP)})

def create_food(name, price):
    food_dict.update({name:Armor(name, price)})


create_herb('생명의 뿌리', 50, '생명의 앨릭서')
create_herb('블러드 베리', 40, '전사의 혈주')
create_herb('아이언 리프', 30, '강철 피부약')
create_herb('마법의 꽃잎', 20, '마나의 샘물')
create_herb('잔디', 0)

create_potion('생명의 앨릭서', 100, 10)
create_potion('전사의 혈주', 80, 8)
create_potion('강철 피부약', 60, 6)
create_potion('마나의 샘물', 40, 4)

create_armor('강철 투구', 100, 2)
create_armor('별서리 견갑', 100, 2)
create_armor('신목 바지', 100, 2)


create_food('황금스프', 30)
create_food('치즈', 20)
create_food('타르트', 20)
create_food('빵', 10)

def make_salelist():
    salelist={}
    for key in all_item_dict.keys():
        r_item = r.choices(list(all_item_dict[key]))
        price = all_item_dict[key][r_item[0]].price
        salelist[r_item[0]]=price
    return salelist


def potion_have(user):
    potion_have = []
    for item in list(user.inventory.keys()):
        if item in potion_dict.keys():
            potion_have.append(potion_dict[item])
    return potion_have

def display_potion(user):
    for i, potion in enumerate(potion_have(user)):
        print(f"{i+1}. {potion.name}")