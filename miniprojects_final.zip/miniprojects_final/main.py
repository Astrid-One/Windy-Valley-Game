from game import *

starting_point = create_map()
newGame = Game(starting_point)
newGame.run()


