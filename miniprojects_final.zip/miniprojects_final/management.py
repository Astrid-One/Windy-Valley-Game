import pygame

pygame.mixer.init()
mainMusic = pygame.mixer.Sound("data\_theme.mp3")
fightMusic = pygame.mixer.Sound("data\_encounter.mp3")
danceMusic = pygame.mixer.Sound("data\_dance.mp3")
shopMusic = pygame.mixer.Sound("data\_shop.mp3")
shopbellSound = pygame.mixer.Sound("data\_shopbell.mp3")

main_channel = pygame.mixer.Channel(0)
fight_channel = pygame.mixer.Channel(1)
dance_channel = pygame.mixer.Channel(2)
shop_channel = pygame.mixer.Channel(3)
shopbell_channel = pygame.mixer.Channel(4)

#Play songs
def play_first_song():
    main_channel.play(mainMusic, loops=-1, fade_ms=5000)

def play_fight_song():
    fight_channel.play(fightMusic, loops=-1, fade_ms=5000)

def play_dance_song():
    dance_channel.play(danceMusic, fade_ms=5000)

def play_shop_song():
    shop_channel.play(shopMusic, fade_ms=5000)

def play_shopbell_sound():
    shopbell_channel.play(shopbellSound)

def play_shop():
    pause_first_song()
    play_shop_song()
    play_shopbell_sound()


#Manage pause and resume of main song
def pause_first_song():
    main_channel.pause()

def resume_first_song():
    main_channel.unpause()


# Stop the musics
def stop_music_fightchannel():
    fight_channel.stop()

def stop_music_menuchannel():
    main_channel.stop()

def stop_music_dancechannel():
    dance_channel.stop()

def stop_music_shopchennel():
    shop_channel.stop()