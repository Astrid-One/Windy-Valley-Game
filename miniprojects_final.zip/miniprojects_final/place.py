import time

class Place:
    def __init__(self, name, objects, monsters, npc, msg):
        self.name = name
        self.objects = objects
        self.monster = monsters 
        self.npc = npc
        self.adjacents_room = [None, None, None, None] # 0 = North, 1 = East, 2 = South, 3 = West
        self.msg = msg
        # self.map = [["-", "상점", "-"],
        #             ["늪지", "마을", "-"],
        #             ["-", "마법의 숲", "버려진 계곡"],
        #             ["-", "신비한 사원", "-"],
        #             ["-", "고대 유적지", "-"]]

    def display_msg(self):
        print(self.msg)
        time.sleep(1)

    def get_name(self):
        return self.name


    def get_place_object(self, i):
        return [self.objects[i]]


    def get_place_npc(self, i):
        return self.npc[i]
    

    def get_place_monsters(self, i):
        return self.monster[i]

    def display_place_npc(self):
        i = 1
        str = ""
        for npc in self.npc:
            str = str + f'{i}' + "." + npc.name + " "
            i += 1
        if i == 1:
            print("이곳에는 NPC가 없습니다.")
        print(str)
        print("\n")

    def get_number_npc(self):
        return len(self.npc)



    def display_place_objects(self):
        i = 1
        str = ""
        for obj in self.objects:
            str = f"{str} {i}. {obj}  "
            i += 1
        if i == 1:
            print("이곳에는 물체가 없습니다.")
        print(str)
        print("\n")
    
    def get_number_objects(self):
        return len(self.objects)


    def display_place_monsters(self):
        i = 1
        str = ""
        for mstr in self.monster:
            str = f"{str} {i}. {mstr.name}"
            i += 1
        if i == 1:
            print("이곳에는 몬스터가 없습니다.")
        print(str)
        print("\n")

    def get_number_monsters(self):
        return len(self.monster)


