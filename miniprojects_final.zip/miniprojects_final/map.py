from items import *
from monster import *
from place import *
from npc import *



def create_villager():
    list_villager = list()
    villager1 = NPC("게롤트")
    villager2 = NPC("예니퍼")
    villager3 = NPC("트리스")
    dragon = NPC("에테리온 드래곤")

    villager1.dialogue_line = '전설에 따르면, 🏛️신비한 사원🏛️에 숨겨진 비밀을 푸는 자만이 고대의 현자들이 남긴 지식을 얻을 수 있다고 하네.'
    villager2.dialogue_line = '🧚마법의 숲🧚에는 에테르의 힘이 깃들어 있다고 해. 소문에는 🧚마법의 숲🧚에는 🏛️신비한 사원🏛️이 있다던데..'
    villager3.dialogue_line = '고대의 현자들은 모든 답을 🏛️신비한 사원🏛️에 남겨두었지. 그들이 남긴 단서를 찾아내야 해.'
    dragon.dialogue_line = 'zzz(거대한 용이 둥지에 몸을 움크리고 자고 있다...강해보인다.. 지금은 건들지 않는 것이 좋을 것 같다...)'

    list_villager.append(villager1)
    list_villager.append(villager2)
    list_villager.append(villager3)
    list_villager.append(dragon)

    return list_villager


def create_map():
    #create the items
    create_food("고기", 4)
    QuestItem('에테르의 기운이 맴도는 목걸이', 10000)
    
    #create villagers
    npcs = create_villager()
    villager1 = npcs[0]
    villager2 = npcs[1]
    villager3 = npcs[2]
    dragon = npcs[3]

    #create the monsters
    sheep =         Monster("양", 10, 1, ['고기','빵'])
    cat =           Monster("고양이", 3, 2, ['고기','빵'])
    chicken =       Monster("닭", 3, 1, ['고기','빵'])
    drakor =        Monster("드라코르", 100, 5, ['타르트','강철 투구','전사의 혈주','아이언 리프'])
    necromancer =   Monster("네크로맨서", 200, 10, ['타르트','강철 투구','전사의 혈주','아이언 리프'])
    silvrin_fairy = Monster("실버린 페어리", 200, 10, ['별서리 견갑', '블러드 베리','치즈'])
    bogweaver =     Monster("보그위버", 500, 30, ['생명의 뿌리', '치즈','생명의 앨릭서'])
    temple_guardian = Monster("사원 가디언", 500, 30, ['생명의 뿌리', '치즈','생명의 앨릭서'])
    ancient_giant = Monster("고대 거인", 500, 30, ['황금스프','블러드 베리','전사의 혈주','아이언 리프','신목 바지'])
    dragon =        Monster("에테리온 드래곤", 3000, 100, ['생명의 뿌리', '황금스프','생명의 앨릭서'])

    #create a list of object for each room
    listObj1 = ['잔디', '동전']
    listObj2 = ['잔디', '동전']
    listObj3 = ['잔디','생명의 뿌리', '블러드 베리']
    listObj4 = ['치즈', '동전']
    listObj5 = ['생명의 뿌리', '아이언 리프']
    listObj6 = ['마법의 꽃잎']
    listObj7 = ['에테르의 기운이 맴도는 목걸이','마법의 꽃잎','동전']

    #create a list of npcs for each room
    npc1 = [villager1, villager2, villager3]
    npc2=[]
    npc3=[dragon]


    monster1 = [sheep, cat, chicken]
    monster2 = [cat]
    monster3 = [drakor, necromancer, silvrin_fairy]
    monster4 = [bogweaver]
    monster5 = [dragon]
    monster6 = [temple_guardian]    
    monster7 = [ancient_giant]

    msg0 = '모든 것이 평화롭다'
    msg1 = '상점이 보인다.'
    msg2 = "나무에 글이 새겨져있다.  '신비한 사원으로 가는길은 멀지 않다.'\n...그리고 이 조그만 글자는 '계곡 용 조심!'"
    msg3 = '으윽,, 고약한 악취가 난다.'
    msg4 = '용이 둥지 위에 몸을 움크리고 있다. ..저 반짝이는게 에테르의 심장인가?'
    msg5 = "사원의 벽에 고대의 문자가 적혀있다.  '고대 유적지로 가라, 그곳에 현자들이 남긴 마지막 단서가 있다.'"
    msg6 = "유적지의 중앙 제단 아래에 희미하게 그림이 보인다.\n계곡에 있는 둥지에서 보석을 지키고 있는 용이 있고, 그 앞에서 목걸이를 들어서 보이고 있는 모습이다.\n여기서 목걸이를 주워서 버려진 계곡으로 가자"

    #create every rooms
    village =       Place("마을", listObj1, monster1, npc1, msg0)
    shop =          Place("상점 앞", listObj2, monster2, npc2, msg1)
    magicalForest = Place("마법의 숲", listObj3, monster3, npc2, msg2)
    swamp =         Place("오염된 늪지", listObj4, monster4, npc2, msg3)
    valley =        Place("버려진 계곡", listObj5, monster5, npc3, msg4)
    temple =        Place("신비한 사원", listObj6, monster6, npc2, msg5)
    ruins =         Place("고대 유적지", listObj7, monster7, npc2, msg6)

    #insert every room as you want in the list of room of each rooms 
    village.adjacents_room[0] = shop
    village.adjacents_room[1] = swamp
    village.adjacents_room[2] = magicalForest

    shop.adjacents_room[2] = village

    magicalForest.adjacents_room[0] = village
    magicalForest.adjacents_room[2] = temple
    magicalForest.adjacents_room[3] = valley

    swamp.adjacents_room[3] = village

    valley.adjacents_room[1] = magicalForest

    temple.adjacents_room[0] = magicalForest
    temple.adjacents_room[2] = ruins

    ruins.adjacents_room[0] = temple

    return village

