import time
from management import *
from items import *

class Fight:
    def __init__(self, user, monster):
        self.win = False
        self.monster = monster
        self.char =user
    
    def play_fight(self):
        play_fight_song()
    
    def game_over(self):
        print(f"")

    def sad_ending(self):
        print('-'*50,"GAME OVER:'(".center(50),'-'*50, sep='\n')
        return False
    
    @classmethod
    def run_fight(cls, user, monster):
        # monAttk, heal or attack, monAttk, heal or attack ...
        round = 1
        cls.play_fight(cls)
        if monster=='dragon':
            print(
            R'''
                                             ,--,  ,.-.
               ,                   \,       '-,-`,'-.' | ._
              /|           \    ,   |\         }  )/  / `-,',
              [ ,          |\  /|   | |        /  \|  |/`  ,`
              | |       ,.`  `,` `, | |  _,...(   (      .',
              \  \  __ ,-` `  ,  , `/ |,'      Y     (   /_L\
               \  \_\,``,   ` , ,  /  |         )         _,/
                \  '  `  ,_ _`_,-,<._.<        /         /
                 ', `>.,`  `  `   ,., |_      |         /
                   \/`  `,   `   ,`  | /__,.-`    _,   `\
               -,-..\  _  \  `  /  ,  / `._) _,-\`       \
                \_,,.) /\    ` /  / ) (-,, ``    ,        |
               ,` )  | \_\       '-`  |  `(               \
              /  /```(   , --, ,' \   |`<`    ,            |
             /  /_,--`\   <\  V /> ,` )<_/)  | \      _____)
       ,-, ,`   `   (_,\ \    |   /) / __/  /   `----`
      (-, \           ) \ ('_.-._)/ /,`    /
      | /  `          `/ \\ V   V, /`     /
   ,--\(        ,     <_/`\\     ||      /
  (   ,``-     \/|         \-A.A-`|     /
 ,>,_ )_,..(    )\          -,,_-`  _--`
(_ \|`   _,/_  /  \_            ,--`
 \( `   <.,../`     `-.._   _,-`
''')
        gameover=False
        while gameover==False:
            print(f"\nROUND : {round}\n")
            #monster turn
            print(f"{monster.name}(이)가 공격해온다.")

            userDamage = monster.AP - user.DP
            user.HP -= userDamage 
            print(f"당신은 {userDamage}데미지를 받았다. {user.HP}HP 남음... \n")
            if user.HP <=0:
                print("당신의 눈이 감긴다....")
                gameover=True      #break
                return cls.sad_ending(cls)
            #user turn
            userturn=True
            while userturn:
                attack_choice = input("1.공격한다  2.포션을 먹는다\n내 답변: ")
                monsterDamage = user.AP # 공증 potion 추가하면 potion 능력치 적용
                if attack_choice.isdecimal():
                    # print("isdecimal check")
                    if attack_choice in ['1','2']:
                        # print("['1','2']pass check")
                        if attack_choice == '1':
                            monster.HP -= monsterDamage
                            print(f"\n당신은 {monsterDamage}데미지를 {monster.name}에게 줬다. {monster.name} {monster.HP}HP 남았다... \n")
                            time.sleep(1)
                            userturn=False
                        elif attack_choice == '2':
                            if len(potion_have(user)):
                                display_potion(user)
                                choice = -1
                                while int(choice) < 0 or int(choice) > len(potion_have(user)):
                                    try:
                                        choice = int(input())
                                        if choice < 1 or choice > len(potion_have(user)):
                                            print("유효한 선택이 아닙니다. 다시 입력해 주세요.\n")
                                        else:
                                            user.out_item(potion_have(user)[choice-1].name)
                                            user.HP += potion_have(user)[choice-1].HP
                                            print(f"{potion_have(user)[choice-1].name}을 마시고 {potion_have(user)[choice-1].HP}회복했다. {user.HP}HP 남음... \n")
                                            time.sleep(1)
                                            userturn=False
                                    except ValueError:
                                        print("숫자를 입력해 주세요.\n") 
                            else:
                                print('가지고 있는 포션이 없습니다.')
                if monster.HP <=0:
                    after_fight_item = monster.random_drop()
                    print(f"당신이 이겼습니다. 전리품:{after_fight_item}을 얻었습니다.")
                    user.in_item(after_fight_item)
                    gameover=True
                    return True
                if monster =='dragon' and monster.HP <= 500:
                    print("에테리온 드래곤: '강한 자를 기다리고 있었다... 이제 나의 진정한 모습을 보여주지.'")
                    return True
            round+=1

    def dragon_event(self, user, monster):
        print("목걸이가 둥지에서 자고 있던 드래곤을 꺠웠다.")
        print(
            R'''                                             __----~~~~~~~~~~~------___
                                  .  .   ~~//====......          __--~ ~~
                  -.            \_|//     |||\\  ~~~~~~::::... /~
               ___-==_       _-~o~  \/    |||  \\            _/~~-
       __---~~~.==~||\=_    -_--~/_-~|-   |\\   \\        _/~
   _-~~     .=~    |  \\-_    '-~7  /-   /  ||    \      /
 .~       .~       |   \\ -_    /  /-   /   ||      \   /
/  ____  /         |     \\ ~-_/  /|- _/   .||       \ /
|~~    ~~|--~~~~--_ \     ~==-/   | \~--===~~        .\
         '         ~-|      /|    |-~\~~       __--~~
                     |-~~-_/ |    |   ~\_   _-~            /\
                          /  \     \__   \/~                \__
                      _--~ _/ | .-~~____--~-/                  ~~==.
                     ((->/~   '.|||' -_|    ~~-/ ,              . _||
                                -_     ~\      ~~---l__i__i__i--~~_/
                                _-~-__   ~)  \--______________--~~
                              //.-~~~-~_--~- |-------~~~~~~~~
                                     //.-~~~--\
''')
        print("에테리온 드래곤: '네가 진정한 강자라면, 나를 이길 수 있을 것이다.'")
        input("목걸이 덕분에 강해진 기분이다. 가보자! (HP 1500증가,  AP 200증가,  DP 200증가)")
        user.HP += 1500;user.AP += 200; user.DP += 200
        result=self.run_fight(user, monster)
        if result:
            print("*펑*")
            print(
                R'''
                oo`'._..---.___..-
                (_,-.        ,..'`
                    `'.    ;
                        : :`
                        _;_;     
                ''')
            time.sleep(1)
            print("몸집이 마을의 고양이만큼 작아졌다.")
            input("에테리온 드래곤:'나의 둥지에서 에테르의 심장을 찾아라. 이 보석은 세상의 균형을 되찾을 것이다'")
            print(r'''
                                    __________________
                                   .-'  \ _.-''-._ /  '-.
                                 .-/\   .'.      .'.   /\-.
                                _'/  \.'   '.  .'   './  \'_
                               :======:======::======:======:  
                                '. '.  \     ''     /  .' .'
                                  '. .  \   :  :   /  . .'
                                    '.'  \  '  '  /  '.'
                                      ':  \:    :/  :'
                                        '. \    / .'
                                          '.\  /.'   
                                            '\/'
                        ''')
            print("이게 바로 에테르의 심장??!")
            print('-'*50,'사실 세상의 평화보다는 돈이 더 좋은 당신은','에테르의 심장을 마을의 암시장에 팔고 부자가 되었다.',"HAPPY ENDING:)".center(50),'-'*50, sep='\n')
        print()


    
