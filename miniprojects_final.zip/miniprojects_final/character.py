# Character class
class Character:
    '''Character Class'''
    def __init__(self, name, inventory, wallet, HP, AP, DP):
        self.name = name
        self.inventory = inventory
        self.__wallet = wallet
        self.HP = HP #health point
        self.AP = AP #attack point
        self.DP = DP #defence
        self.maxHP = 100

    def in_item(self, items):
        for item in items:
            if item == '동전':
                self.get_money()
            else:
                if item in self.inventory:
                    self.inventory[item]+=1
                else:
                    self.inventory[item]=1
        self.money=int(self.__wallet)

    def out_item(self, item):
        if item in self.inventory:
            self.inventory[item]-=1
            if self.inventory[item] == 0:
                del self.inventory[item]
        print(f"{item}을 소지품에서 제외".center(45,'-'))
        print(f"소지품 목록 {self.inventory}\n소지품 개수: {sum(self.inventory.values())}")
        print(''.center(45, '-'), end='\n\n')

    def get_wallet(self):
        return self.__wallet


    def pay_money(self, price):
        if self.__wallet >= price:
            self.__wallet -= price
            self.money=int(self.__wallet)
            print(f'사용 후 남은 코인: {self.__wallet}')
            return True
        else:
            return False


    def add_inventory(self, object):
        self.inventory.append(object)


    def get_money(self):
        self.__wallet += 100


    def check_inventory(self):
        print(f"{self.name}'s bag".center(45,'-'))
        print(f"가방 확인:{self.inventory}\n소지품 종류: {list(self.inventory.keys())}\n소지품 개수: 총 {sum(self.inventory.values())}개")
        print(''.center(45, '-'), end='\n\n')

    def open_wallet(self):
        print(f"{self.name}'s Wallet".center(45,'-'))
        print(f"{self.name}님의 소지금은 {self.get_wallet()}입니다.")

    def show_money(self):
        print(f"{self.name}님의 소지금은 {self.get_wallet()}입니다.\n")

    def attack(self, user):
        print(f"{user.name}은(는) 기본 공격을 했다.")
        return self.AP

    def drink_potion(self, user, potion):
        print(f"{user.name}은(는) {potion.name}을(를) 마시고 {potion.HP}만큼 회복했다.")
        potion.heal(user.name) #$$$


    def reset_char_HP(self):
        self.HP = self.maxHP


# Knight class
class Knight(Character):
    '''Knight Class AP+10, DP+10'''
    def __init__(self, name, inventory, wallet, HP, AP, DP):
        super().__init__(name, inventory, wallet, HP, AP, DP)
        self.AP = AP + 10
        self.DP = DP + 10
    def slash(self):
        print("당신은 가르기를 했다.")
        return self.AP + 20
    def stap(self):
        print("당신은 찌르기를 했다.")
        return self.AP + 20

# Magician
class Mage(Character):
    '''Mage Class AP+20'''
    def __init__(self, name, inventory, wallet, HP, AP, DP):
        super().__init__(name, inventory, wallet, HP, AP, DP)
        self.AP = AP + 20
    def explode(self):
        print("당신은 화염 폭발을 시전했다.")
        return self.AP + 20
    def freeze(self):
        print("당신은 급속 냉동을 시전했다.")
        return self.AP + 20

# Healer
class Healer(Character):
    '''Healer Class DP+10, inventory+herbs'''
    def __init__(self, name, inventory, wallet, HP, AP, DP):
        super().__init__(name, inventory, wallet, HP, AP, DP)
        self.DP = DP + 10
    def heal(self, user): #한번의 heal 10
        return user.HP + 10
    def make_potion(self, herb):
        if herb in self.inventory and self.inventory[herb]:
            super().out_item(herb)
            potion_name = f"{herb}_potion"
            if potion_name in self.inventory:
                self.inventory[potion_name] += 1
            else:
                self.inventory[potion_name] = 1
            print(f"{self.name} made a {potion_name} using {herb}!")    # When I decide potion_name
        else:
            print(f"{herb}가 가방에 없습니다.") # use 'herbs' make 'potion'


def create_character():
    user_name = input("닉네임을 입력해주세요:")
    while(len(user_name) < 2):
        print("\nincorrect username, try again\n")
        user_name = input("닉네임을 입력해주세요:")
    while True:
        user_char=input("\n직업 선택(번호 입력)?\n1.기사(공격력, 방어력 증가)   2.마법사(공격력 증가)   3.힐러(방어력 증가/포션 제작)\n내 답변:").strip()
        if user_char.isdecimal():
            if int(user_char) >= 4 or int(user_char) < 1:
                print("\n선택지에 있는 값이 아닙니다.")
            elif user_char == '1':
                user_char = Knight(name=user_name, inventory={}, wallet=1000, HP=100, AP=50, DP=5)
                print("\n*** 이 세계에 어서오세요 용감한 기사님 ***\n")
                break
            elif user_char == '2':
                user_char = Mage(name=user_name, inventory={}, wallet=1000, HP=100, AP=50, DP=5)
                print("\n*** 이 세계에 어서오세요 이상한 마법사님 ***\n")
                break
            else:
                user_char = Healer(name=user_name, inventory={}, wallet=1000, HP=100, AP=50, DP=5)
                print("\n*** 이 세계에 어서오세요 연약한 힐러님 ***\n")
                break
        else:
            print('\n올바른 데이터가 입력되지 않았습니다....\n')
            create_character()
    return user_char