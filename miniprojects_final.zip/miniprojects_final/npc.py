import random as rd
import time

class NPC:
    def __init__(self, name):
        self.name = name
        dialogue_line = list()

    def greeting(self):
        greeting=['안녕하세요','안녕하신가','좋은 아침','날씨 좋네','안녕?','어이!','*켈록켈록*','*에잇, 쯧!*','*휴*','*콜록콜록*','*크흠*','하하']
        print(f"{self.name}: {rd.choice(greeting)}")
        time.sleep(0.7)


    def saying(self):
        input(f"{self.name}:  {self.dialogue_line}\n")

    # def saying(self, npc):
    #     setences={'villiger1':'전설에 따르면, 신비한 사원에 숨겨진 비밀을 푸는 자만이 고대의 현자들이 남긴 지식을 얻을 수 있다고 하네.',
    #               'villiger2':'마법의 숲에는 에테르의 힘이 깃들어 있다고 해. 소문에는 마법의 숲에는 신비한 사원이 있다던데..',
    #               'villiger3':'고대의 현자들은 모든 답을 신비한 사원에 남겨두었지. 그들이 남긴 단서를 찾아내야 해.',
    #               'msg1':'신비한 사원으로 가는 길은 그리 멀지 않다. 숲의 중심을 찾아라', #마법의 숲(숲 깊은 곳에 있는 나무에 글이 새겨져 있다.)
    #               'msg2':'고대 유적지로 가라, 그곳에 현자들이 남긴 마지막 단서가 있다.', #사원의 벽(사원의 벽에 고대의 문자가 새겨져 있다.)
    #               'msg3':'버려진 계곡에서 전설의 용을 찾아라. 그는 에테르의 심장을 지키고 있다.', #고대 유적지(유적지의 중앙 제단에 글이 새겨져 있다.)
    #               'dragon':'네가 진정한 강자라면, 나를 이길 수 있을 것이다.', #전투 중 용의 대사
    #               'dragon2':'강한 자를 기다리고 있었다... 이제 나의 진정한 모습을 보여주지.', #용의 HP가 낮아졌을 때
    #               'dragon3':'나의 둥지에서 에테르의 심장을 찾아라. 이 보석은 세상의 균형을 되찾을 것이다'} #작고 귀여운 모습으로 변한 용
        # return setences[npc]
